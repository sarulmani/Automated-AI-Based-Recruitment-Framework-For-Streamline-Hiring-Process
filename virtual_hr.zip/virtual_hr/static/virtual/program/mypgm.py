a=10
b=20
if a>b:
   print("A is big"+str(a))
else:
   print("B is big"+str(b))
