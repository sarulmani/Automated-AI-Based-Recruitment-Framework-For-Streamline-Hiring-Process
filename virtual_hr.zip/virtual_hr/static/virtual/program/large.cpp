#include <iostream>
using namespace std;
int main() {    
    float n1, n2, n3;
    //cout << "Enter three numbers: ";
    //cin >> n1 >> n2 >> n3;
n1=145;
n2=94;
n3=30;
    if(n1 >= n2 && n1 >= n3)
        cout << "Largest number: " << n1;
    if(n2 >= n1 && n2 >= n3)
        cout << "Largest number: " << n2;
    if(n3 >= n1 && n3 >= n2)
        cout << "Largest number: " << n3;
    return 0;
}