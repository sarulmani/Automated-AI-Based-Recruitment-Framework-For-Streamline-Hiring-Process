#include <stdio.h>
int main() {
    int a, b, product;
    //printf("Enter two numbers: ");
    a=2;
    b=50;
    // Calculating product
    product = a * b;
    // %.2lf displays number up to 2 decimal point
    printf("Product = %d", product);
    return 0;
}