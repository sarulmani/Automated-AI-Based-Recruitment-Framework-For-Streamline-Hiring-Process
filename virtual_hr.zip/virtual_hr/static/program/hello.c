#include<stdio.h> 
 
int main() 
{ 
	printf("Hello World\n"); 
	printf("This C program Running\n"); 
	return 0; 
} 
